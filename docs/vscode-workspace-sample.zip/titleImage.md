
Title[](title)

[Sergey A Kryukov](http://www.sakryukov.org)

# AAA

# Contents{.special-CSS-class}

[](toc)

## Superscripts and Subscripts

[](include(eq.md)) E = mc^2^
This works: A~n,m~ = B~j,k~, but space inside subscript/superscript expression won't.

# AAA

## File Includes
```
[](include(.vscode/settings.json))
``` 
## Footnotes

Let's say, we want to reference a footnote [^first] and one more, a long one [^long].

Let's reference the same footnote [^first].

[^first]: This is the footnote itself.
We have indication that this footnote is referenced from two places:

[^long]:
    This is a long footnote.

    One paragraph.

    Another paragraph.

    As many as we want...

    We need to have many footnote paragraphs, to illustrate the location of footnotes.

    ...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>...<br/>

    That's enough.

## Inline Notes

Here is an inline note.^[Inline notes are easier to write, since
you don't have to pick an identifier and move down to type the
note. &copy; [markdown-it-footnote](https://www.npmjs.com/package/markdown-it-footnote)]

# AAA