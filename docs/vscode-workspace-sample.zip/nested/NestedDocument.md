# This is a nested document

It demonstrates that commands Markdown: Convert to HTML" and "Markdown: Convert to HTML all .md files in workspace" (see context menu on editor or explorer) convert markdown files to HTML and place the output to the same directory as the source .md file.
